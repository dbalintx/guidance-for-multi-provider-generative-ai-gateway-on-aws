Stand-in code bundle for terraform test.
